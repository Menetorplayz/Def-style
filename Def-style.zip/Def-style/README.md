# Def-style
by Menetorplayz

![Template](Template.png)

## Licensing
Creative Commons Attribution-Share Alike 4.0 International License
